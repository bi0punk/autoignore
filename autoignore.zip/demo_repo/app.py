from pathlib import Path

print("Demo app")
print(Path("logs/app.log").resolve())
